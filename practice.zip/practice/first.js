const sundar=require('fs')
sundar.writeFileSync('hello.txt','welcome to the page created by node')